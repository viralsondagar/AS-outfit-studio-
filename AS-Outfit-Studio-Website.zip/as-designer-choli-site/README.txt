AS OUTFIT STUDIO — WEBSITE FILES

Website language: English only.

Files included:
- index.html: responsive outfit rental catalogue with search, price filters, and WhatsApp enquiry flow.
- assets/: outfit photos and logo. Photos are included as supplied and are not edited.

Website setup:
- Brand: AS Outfit Studio
- Instagram: https://instagram.com/as_outfit_studio
- WhatsApp booking: +91 93273 92419
- Rental period: 2 days
- Dry cleaning: handled by the studio
- Hosting: GitHub Pages (free)

IMPORTANT — HOW TO UPLOAD
1. Download this ZIP and extract/unzip it on your device.
2. Open the extracted as-designer-choli-site folder.
3. Upload index.html and the complete assets folder into the ROOT of your GitHub repository. Do not upload only the ZIP: GitHub Pages will not automatically extract it.
4. In the repository, open Settings > Pages. Under Build and deployment, choose Deploy from a branch, branch main, folder /(root), then Save.
5. Wait for GitHub Pages to publish and open the URL shown in Settings > Pages.

EDITING INFORMATION
Product names, prices, and colours are currently stored in the products array inside index.html. Update the matching product row and image filename there, then upload the changed file to GitHub. A static GitHub Pages site does not include a secure admin dashboard; changes are made by editing and re-uploading the file.
